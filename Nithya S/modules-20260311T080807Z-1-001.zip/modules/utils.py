import os
import json
import time
from fpdf import FPDF
import streamlit as st


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SAVE_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".narrativeflow_saves")

GENRE_THEMES = {
    "Fantasy": {
        "video": "https://assets.mixkit.co/videos/preview/mixkit-starry-night-sky-over-a-mountain-range-4353-large.mp4",
        "overlay_start": "rgba(60,20,100,0.5)",
        "overlay_end": "rgba(0,10,40,0.6)",
        "accent": "#9d77f5",
    },
    "Sci-Fi": {
        "video": "https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-a-circuit-board-1127-large.mp4",
        "overlay_start": "rgba(0,30,60,0.5)",
        "overlay_end": "rgba(0,60,80,0.6)",
        "accent": "#00d4ff",
    },
    "Mystery": {
        "video": "https://assets.mixkit.co/videos/preview/mixkit-mysterious-foggy-forest-at-night-44391-large.mp4",
        "overlay_start": "rgba(10,10,20,0.6)",
        "overlay_end": "rgba(30,15,0,0.5)",
        "accent": "#f0b429",
    },
    "Romance": {
        "video": "https://assets.mixkit.co/videos/preview/mixkit-close-up-of-sparklers-burning-in-the-dark-44359-large.mp4",
        "overlay_start": "rgba(80,10,40,0.45)",
        "overlay_end": "rgba(40,0,20,0.55)",
        "accent": "#ff7eb3",
    },
    "Horror": {
        "video": "https://assets.mixkit.co/videos/preview/mixkit-dark-and-spooky-forest-with-mist-44383-large.mp4",
        "overlay_start": "rgba(5,0,0,0.65)",
        "overlay_end": "rgba(20,0,0,0.7)",
        "accent": "#cc2222",
    },
}

DEFAULT_POSTER = "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExemY5cXg3amg3eTFldzQyd25iOThwZm9xb3pxcmQ2Z3lzbmh3NmVsbCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/3ov9k6nCKUAHnzL41q/giphy.gif"


# ---------------------------------------------------------------------------
# Session State Initialization
# ---------------------------------------------------------------------------

def init_session_state():
    """Initialize all session state keys with defaults."""
    defaults = {
        "projects": {"Welcome Story": {"history": [], "created_at": time.time()}},
        "current_project": "Welcome Story",
        "messages": [],
        "story_title": "New Masterpiece",
        "system_prompt": "",
        "model": "llama3",
        "is_generating": False,
        "ollama_ok": False,
        "ollama_err": "",
        "ollama_checked": False,
        "characters": [],           # List of character dicts
        "story_summary": "",        # Auto-generated narrative summary
        "pitch": None,              # Currently displayed pitch card
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


# ---------------------------------------------------------------------------
# Project Persistence (JSON)
# ---------------------------------------------------------------------------

def save_project(project_name: str, data: dict):
    """Save a project's full state to a JSON file."""
    os.makedirs(SAVE_DIR, exist_ok=True)
    safe_name = "".join(c if c.isalnum() or c in " _-" else "_" for c in project_name)
    path = os.path.join(SAVE_DIR, f"{safe_name}.json")
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception:
        pass  # Non-critical; in-memory state stays intact


def load_project(project_name: str) -> dict:
    """Load a project's state from disk. Returns {} if not found."""
    safe_name = "".join(c if c.isalnum() or c in " _-" else "_" for c in project_name)
    path = os.path.join(SAVE_DIR, f"{safe_name}.json")
    if os.path.exists(path):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


# ---------------------------------------------------------------------------
# Story History Categorization
# ---------------------------------------------------------------------------

def get_categorized_history(projects: dict) -> dict:
    """Categorize projects by time of creation (Today / Yesterday / 7 Days / Older)."""
    now = time.time()
    day = 86_400
    categories = {"Today": [], "Yesterday": [], "Previous 7 Days": [], "Older": []}

    for name, data in projects.items():
        diff = now - data.get("created_at", 0)
        if diff < day:
            categories["Today"].append(name)
        elif diff < day * 2:
            categories["Yesterday"].append(name)
        elif diff < day * 7:
            categories["Previous 7 Days"].append(name)
        else:
            categories["Older"].append(name)

    return {k: v for k, v in categories.items() if v}


# ---------------------------------------------------------------------------
# Message Rendering
# ---------------------------------------------------------------------------

def render_message(role: str, content: str):
    """Render a chat message with Claude-style avatar bubbles."""
    if role == "user":
        avatar_char = "✍️"
        bubble_class = "user-bubble"
    else:
        avatar_char = "✒️"
        bubble_class = "ai-story-bubble"

    st.markdown(
        f'<div class="message-row {bubble_class}-row">'
        f'  <div class="avatar {"user-avatar" if role == "user" else "ai-avatar"}">{avatar_char}</div>'
        f'  <div class="{bubble_class}">{content}</div>'
        f'</div>',
        unsafe_allow_html=True,
    )


def render_skeleton():
    """Render a skeleton loading placeholder while the AI is generating."""
    st.markdown(
        '<div class="message-row ai-bubble-row">'
        '  <div class="avatar ai-avatar">✒️</div>'
        '  <div class="ai-story-bubble skeleton-wrapper">'
        '    <div class="skeleton-line" style="width:92%"></div>'
        '    <div class="skeleton-line" style="width:98%"></div>'
        '    <div class="skeleton-line" style="width:85%"></div>'
        '    <div class="skeleton-line" style="width:76%"></div>'
        '  </div>'
        '</div>',
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Genre Background Injection
# ---------------------------------------------------------------------------

def inject_custom_bg(genre: str):
    """
    Inject an immersive, animated cinematic background based on genre.
    Uses per-genre accent CSS variables and smooth overlay transitions.
    """
    theme = GENRE_THEMES.get(genre, GENRE_THEMES["Fantasy"])
    bg_video = theme["video"]
    overlay_start = theme["overlay_start"]
    overlay_end = theme["overlay_end"]
    accent = theme["accent"]

    st.markdown(
        f"""
        <style>
        :root {{
            --genre-accent: {accent};
            --genre-glow: {accent}40;
        }}
        .custom-bg {{
            position: fixed; top: 0; left: 0;
            width: 100vw; height: 100vh;
            object-fit: cover; z-index: -2;
            background-color: #0d0b14;
            transition: opacity 0.8s ease-in-out;
        }}
        .bg-overlay {{
            position: fixed; top: 0; left: 0;
            width: 100vw; height: 100vh;
            background: linear-gradient(135deg, {overlay_start}, {overlay_end});
            z-index: -1;
            transition: background 1.2s ease-in-out;
        }}
        .stApp, [data-testid="stAppViewContainer"],
        [data-testid="stHeader"], [data-testid="stMain"] {{
            background: transparent !important;
        }}
        </style>
        <video class="custom-bg" autoplay loop muted playsinline poster="{DEFAULT_POSTER}">
            <source src="{bg_video}" type="video/mp4">
        </video>
        <div class="bg-overlay"></div>
        """,
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# Manuscript Export — TXT
# ---------------------------------------------------------------------------

def create_txt_download(messages: list[dict], title: str) -> bytes:
    """
    Export the story as clean prose-only TXT.
    User prompts are omitted — only AI-generated story text is included.
    """
    separator = "=" * 60
    lines = [separator, f"  {title.upper()}", separator, "", "  Generated with NarrativeFlow", "", separator, ""]

    for msg in messages:
        if msg.get("role") == "assistant":
            lines.append(msg["content"].strip())
            lines.append("")  # Paragraph break between turns

    return "\n".join(lines).encode("utf-8")


# ---------------------------------------------------------------------------
# Manuscript Export — PDF
# ---------------------------------------------------------------------------

class _ManuscriptPDF(FPDF):
    """FPDF subclass with manuscript-style header and footer."""
    story_title = ""

    def header(self):
        if self.page_no() > 1:
            self.set_font("Times", "I", 9)
            self.set_text_color(140, 120, 180)
            self.cell(0, 8, self.story_title, align="C", ln=True)
            self.ln(2)

    def footer(self):
        self.set_y(-14)
        self.set_font("Times", "I", 9)
        self.set_text_color(140, 120, 180)
        self.cell(0, 8, f"- {self.page_no()} -", align="C")


def create_pdf_download(messages: list[dict], title: str) -> bytes:
    """
    Export the story as a typeset, manuscript-quality PDF.
    Includes a title page, header/footer, 1-inch margins, and Times New Roman body.
    """
    pdf = _ManuscriptPDF(orientation="P", unit="mm", format="A4")
    _ManuscriptPDF.story_title = title
    pdf.set_margins(left=25.4, top=25.4, right=25.4)
    pdf.set_auto_page_break(auto=True, margin=20)

    # --- Title Page ---
    pdf.add_page()
    pdf.ln(50)
    pdf.set_font("Times", "B", 26)
    pdf.set_text_color(60, 40, 100)
    pdf.multi_cell(0, 14, title, align="C")
    pdf.ln(6)
    pdf.set_font("Times", "I", 12)
    pdf.set_text_color(110, 90, 150)
    pdf.cell(0, 8, "Written with NarrativeFlow  |  Powered by Llama 3", align="C", ln=True)
    pdf.ln(30)
    pdf.set_font("Times", "", 10)
    pdf.set_text_color(150, 130, 180)
    pdf.cell(0, 6, "March 2026", align="C", ln=True)

    # --- Story Body ---
    pdf.add_page()
    pdf.set_font("Times", "", 12)
    pdf.set_text_color(30, 20, 50)

    for msg in messages:
        if msg.get("role") == "assistant":
            text = msg["content"].strip()
            # Encode safely for PDF
            text = text.encode("latin-1", "replace").decode("latin-1")
            pdf.multi_cell(0, 7, text)
            pdf.ln(5)

    return bytes(pdf.output(dest="S"))
