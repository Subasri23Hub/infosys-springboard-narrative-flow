import os
import json
import re
import ollama
import streamlit as st


# ---------------------------------------------------------------------------
# Prompt Loader
# ---------------------------------------------------------------------------

def load_prompt(name: str) -> str:
    """Load a prompt template from the prompts/ directory."""
    path = os.path.join("prompts", f"{name}.txt")
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""


# ---------------------------------------------------------------------------
# Scope Enforcement
# ---------------------------------------------------------------------------

# Phrases that are always welcome — greetings, small talk, story chat
_ALWAYS_VALID_PATTERNS = [
    "hello", "hi ", "hi!", "hey", "howdy", "good morning", "good evening",
    "good afternoon", "how are you", "what can you do", "what do you do",
    "tell me about", "help me", "let's write", "let us write", "i want to write",
    "i'd like to write", "can you write", "write a story", "write me a",
    "once upon", "story about", "narrative", "character", "plot", "scene",
    "what is narrativeflow", "who are you", "nice to meet",
]

_OUT_OF_SCOPE_KEYWORDS = [
    "how to code", "write a function", "write a script", "python script",
    "javascript code", "debug this", "fix my code",
    "solve for x", "what is the integral",
    "what is the capital of", "who invented", "stock price",
    "give me a recipe", "medical advice", "legal advice", "tax advice",
    "what is the weather", "translate this document",
]


def is_always_valid(prompt: str) -> bool:
    """Returns True for greetings and clearly story-related inputs that should never be blocked."""
    p = prompt.lower().strip()
    # Very short inputs (≤4 words) default to valid — let the LLM handle them
    if len(p.split()) <= 4 and not any(kw in p for kw in _OUT_OF_SCOPE_KEYWORDS):
        return True
    return any(pattern in p for pattern in _ALWAYS_VALID_PATTERNS)


def fast_scope_prefilter(prompt: str) -> bool:
    """
    Returns True if the prompt is obviously out of scope.
    This avoids an LLM call for clear-cut rejections.
    """
    p = prompt.lower()
    return any(kw in p for kw in _OUT_OF_SCOPE_KEYWORDS)


def validate_story_input(prompt: str, model: str = "llama3") -> tuple[bool, str]:
    """
    Three-stage scope validation.
    Stage 0: allowlist check for greetings and story-related phrases (always pass).
    Stage 1: fast keyword pre-filter (no LLM call) for obvious rejections.
    Stage 2: LLM gatekeeper for ambiguous inputs.
    Returns (is_valid, rejection_message).
    """
    # Stage 0 — always let greetings and casual story chat through
    if is_always_valid(prompt):
        return True, ""

    # Stage 1 — instant keyword check for clear out-of-scope topics
    if fast_scope_prefilter(prompt):
        return False, (
            "✒️ I'm NarrativeFlow, your storytelling companion — that topic is a little outside "
            "my creative world! But I'd love to weave it into a story. "
            "Try: *'Write a tale where a character must deal with [that topic]...'*"
        )

    # Stage 2 — LLM gatekeeper
    template = load_prompt("gatekeeper")
    validation_prompt = template.format(prompt=prompt) if template else (
        f"Is this a story writing request? Reply VALID or explain why not.\n\nPrompt: {prompt}"
    )

    try:
        response = ollama.generate(model=model, prompt=validation_prompt, stream=False)
        content = response.get("response", "").strip()

        if content.upper().startswith("VALID"):
            return True, ""
        else:
            rejection = content if content else (
                "✒️ I'd love to help, but I'm specialized in co-writing fictional stories! "
                "How about we write a scene about that instead?"
            )
            return False, rejection
    except Exception:
        return True, ""  # Fail open — don't block the writer on a tech error


# ---------------------------------------------------------------------------
# Character Block Builder
# ---------------------------------------------------------------------------

def build_character_block(characters: list[dict]) -> str:
    """Build the character profiles section of the system prompt."""
    if not characters:
        return ""
    lines = ["\n\nCHARACTER PROFILES (maintain complete consistency across all turns):"]
    for c in characters:
        lines.append(
            f"- {c.get('name', 'Unknown')} ({c.get('role', 'Character')}): "
            f"{c.get('personality', '')}. "
            f"Motivation: {c.get('motivation', '')}. "
            f"Appears as: {c.get('appearance', '')}. "
            f"Defining trait: {c.get('special_trait', '')}."
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# System Prompt Construction
# ---------------------------------------------------------------------------

def build_system_prompt(
    title: str,
    genre: str,
    tone: str,
    word_limit: int,
    characters: list[dict] = None,
    custom: str = "",
    story_summary: str = "",
) -> str:
    """Construct the full system prompt from all story settings."""
    template = load_prompt("system_base")
    if template:
        base = template.format(
            title=title,
            genre=genre,
            tone=tone,
            word_limit=word_limit,
        )
    else:
        base = (
            f"You are NarrativeFlow, a world-class creative writing companion. "
            f"Your sole purpose is to co-write an immersive story titled '{title}'.\n"
            f"Context: Genre={genre} | Tone={tone} | Target={word_limit} words per turn.\n\n"
            f"GUIDELINES:\n"
            f"1. Write exclusively in vivid, atmospheric narrative prose.\n"
            f"2. Show, don't tell. Prioritize sensory details and emotional depth.\n"
            f"3. Never include meta-commentary, bullet lists, or headers.\n"
            f"4. Continue seamlessly from the user's latest input.\n"
            f"5. Maintain consistent character voices and narrative logic.\n"
            f"6. End each response at a natural dramatic beat — never mid-sentence.\n"
        )

    if story_summary:
        base += f"\n\nSTORY SO FAR (narrative summary — use this for continuity):\n{story_summary}"

    if characters:
        base += build_character_block(characters)

    if custom and custom.strip():
        base += f"\n\nSPECIAL DIRECTIVES: {custom.strip()}"

    return base


# ---------------------------------------------------------------------------
# Story Generation (Streaming)
# ---------------------------------------------------------------------------

def generate_story(
    messages: list[dict],
    title: str,
    genre: str,
    tone: str,
    word_limit: int,
    model: str = "llama3",
    system_prompt: str = "",
    characters: list[dict] = None,
    story_summary: str = "",
):
    """
    Stream story text from Ollama, token by token.
    Yields string chunks as they arrive.
    Raises ConnectionError if Ollama is unreachable.
    """
    if system_prompt and system_prompt.strip():
        sys_prompt = system_prompt
    else:
        sys_prompt = build_system_prompt(
            title, genre, tone, word_limit,
            characters=characters,
            story_summary=story_summary,
        )

    ollama_messages = [{"role": "system", "content": sys_prompt}]
    for msg in messages:
        ollama_messages.append({"role": msg["role"], "content": msg["content"]})

    try:
        stream = ollama.chat(model=model, messages=ollama_messages, stream=True)
        for chunk in stream:
            delta = chunk.get("message", {}).get("content", "")
            if delta:
                yield delta
    except Exception as e:
        raise ConnectionError(str(e)) from e


# ---------------------------------------------------------------------------
# Story Memory Compression
# ---------------------------------------------------------------------------

TOKEN_THRESHOLD = 8000  # ~6,000 words before compression kicks in


def estimate_tokens(messages: list[dict]) -> int:
    """Rough token estimate: 1 token ≈ 4 characters."""
    return sum(len(m.get("content", "")) for m in messages) // 4


def summarize_story_so_far(messages: list[dict], model: str = "llama3") -> str:
    """
    Compress the assistant's story output into a 300-word narrative summary.
    Preserves key plot events, character arcs, and unresolved tensions.
    """
    story_text = "\n\n".join(
        m["content"] for m in messages if m.get("role") == "assistant"
    )
    if not story_text.strip():
        return ""

    template = load_prompt("summarize")
    summarize_prompt = (
        template.format(story_text=story_text) if template else
        f"Summarize the following story in 300 words, present tense, third person:\n\n{story_text}"
    )

    try:
        response = ollama.generate(model=model, prompt=summarize_prompt, stream=False)
        return response.get("response", "").strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Random Story Pitch Generator
# ---------------------------------------------------------------------------

def generate_story_pitch(genre: str, tone: str, model: str = "llama3") -> dict:
    """
    Generate a structured story pitch using the LLM.
    Returns a dict with keys: title, setting, protagonist, conflict, twist, opening_line.
    Returns {} on failure.
    """
    template = load_prompt("pitch_generator")
    pitch_prompt = (
        template.format(genre=genre, tone=tone) if template else
        f"Generate a {genre} story pitch in JSON with: title, setting, protagonist, conflict, twist, opening_line."
    )

    try:
        response = ollama.generate(model=model, prompt=pitch_prompt, stream=False)
        raw = response.get("response", "").strip()
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            return json.loads(match.group())
        return {}
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# Ollama Health Check
# ---------------------------------------------------------------------------

def check_ollama(model: str = "llama3") -> tuple[bool, str]:
    """
    Returns (True, '') if Ollama is reachable and model is available.
    Returns (False, error_message) otherwise.
    """
    try:
        response = ollama.list()
        models = [m.model for m in response.models]
        if not any(model in m for m in models):
            return False, (
                f"Model **{model}** is not pulled yet. "
                f"Run `ollama pull {model}` in your terminal, then refresh."
            )
        return True, ""
    except Exception as e:
        return False, (
            "Cannot reach Ollama. Make sure it is running: `ollama serve`  \n"
            f"Details: `{e}`"
        )
