import time
import streamlit as st
from modules.utils import get_categorized_history, save_project
from modules.llm import generate_story_pitch


# ---------------------------------------------------------------------------
# Sidebar — Main Entry Point
# ---------------------------------------------------------------------------

def render_sidebar():
    """Render the full sidebar and return current story settings dict."""
    with st.sidebar:
        st.markdown(
            '<div class="sidebar-logo">NarrativeFlow ✒️</div>',
            unsafe_allow_html=True,
        )

        # ── New Story Button ──────────────────────────────────────────────
        if st.button("＋ New Story", use_container_width=True, type="primary"):
            # Save current project before creating new
            _save_current_project()
            new_name = f"Story {len(st.session_state['projects']) + 1}"
            st.session_state["projects"][new_name] = {
                "history": [],
                "characters": [],
                "created_at": time.time(),
            }
            st.session_state["current_project"] = new_name
            st.session_state["messages"] = []
            st.session_state["characters"] = []
            st.session_state["story_summary"] = ""
            st.session_state["story_title"] = "New Masterpiece"
            st.session_state["pitch"] = None
            st.session_state["ollama_checked"] = False
            st.rerun()

        st.divider()

        # ── Story History ─────────────────────────────────────────────────
        st.markdown('<div class="history-label">Story History</div>', unsafe_allow_html=True)
        categories = get_categorized_history(st.session_state["projects"])

        for cat, items in categories.items():
            st.caption(f"**{cat}**")
            for item in items:
                is_active = item == st.session_state["current_project"]
                label = f"📄 {item[:22]}{'…' if len(item) > 22 else ''}"
                if st.button(
                    label,
                    key=f"hist_{item}",
                    use_container_width=True,
                    type="primary" if is_active else "secondary",
                ):
                    _save_current_project()
                    proj = st.session_state["projects"][item]
                    st.session_state["current_project"] = item
                    st.session_state["messages"] = proj.get("history", [])
                    st.session_state["characters"] = proj.get("characters", [])
                    st.session_state["story_summary"] = proj.get("story_summary", "")
                    st.session_state["story_title"] = proj.get("story_title", "New Masterpiece")
                    st.session_state["ollama_checked"] = False
                    st.rerun()

        st.divider()

        # ── Story Settings ────────────────────────────────────────────────
        with st.expander("⚙️ Story Settings", expanded=False):
            st.session_state["story_title"] = st.text_input(
                "Story Title", value=st.session_state["story_title"]
            )
            st.session_state["system_prompt"] = st.text_area(
                "Custom Instructions",
                value=st.session_state.get("system_prompt", ""),
                placeholder="Optional: override AI persona, style, or voice…",
                help="Leave blank to use the default NarrativeFlow system prompt.",
            )
            genre = st.selectbox("Genre", ["Fantasy", "Sci-Fi", "Mystery", "Romance", "Horror"])
            tone = st.selectbox("Tone", ["Serious", "Humorous", "Dark", "Optimistic", "Formal"])
            word_limit = st.slider("Words per Turn", 100, 2000, 500, step=50)

        # ── Character Builder ─────────────────────────────────────────────
        _render_character_builder()

        # ── Random Pitch Generator ────────────────────────────────────────
        _render_pitch_generator(genre, tone)

        return {
            "title": st.session_state["story_title"],
            "genre": genre,
            "tone": tone,
            "word_limit": word_limit,
        }


# ---------------------------------------------------------------------------
# Character Builder
# ---------------------------------------------------------------------------

def _render_character_builder():
    """Render the Character Builder expander in the sidebar."""
    chars = st.session_state.get("characters", [])
    label = f"🧑‍🤝‍🧑 Characters ({len(chars)})" if chars else "🧑‍🤝‍🧑 Character Builder"

    with st.expander(label, expanded=False):
        # Display existing characters
        if chars:
            for i, c in enumerate(chars):
                col1, col2 = st.columns([4, 1])
                with col1:
                    role_icon = {"Protagonist": "🌟", "Antagonist": "🔱", "Mentor": "🦉",
                                 "Ally": "🤝", "Other": "👤"}.get(c.get("role", "Other"), "👤")
                    st.markdown(
                        f'<div class="char-chip">{role_icon} <strong>{c["name"]}</strong> '
                        f'<span class="char-role">({c["role"]})</span></div>',
                        unsafe_allow_html=True,
                    )
                with col2:
                    if st.button("✕", key=f"del_char_{i}", help="Remove character"):
                        st.session_state["characters"].pop(i)
                        st.rerun()
            st.divider()

        # Add new character form
        st.markdown("**Add Character**")
        with st.form("char_form", clear_on_submit=True):
            name = st.text_input("Name *", placeholder="e.g. Elan Morin")
            role = st.selectbox("Role", ["Protagonist", "Antagonist", "Mentor", "Ally", "Other"])
            personality = st.text_area("Personality", placeholder="Stoic, calculating, haunted by past failures…", height=68)
            motivation = st.text_input("Motivation", placeholder="Seeks redemption by preventing war")
            appearance = st.text_input("Appearance", placeholder="Tall, silver-streaked hair, grey eyes")
            special_trait = st.text_input("Defining Trait", placeholder="Can read emotions like text")

            submitted = st.form_submit_button("＋ Add to Story", use_container_width=True)
            if submitted and name.strip():
                new_char = {
                    "name": name.strip(),
                    "role": role,
                    "personality": personality.strip(),
                    "motivation": motivation.strip(),
                    "appearance": appearance.strip(),
                    "special_trait": special_trait.strip(),
                }
                st.session_state["characters"].append(new_char)
                st.success(f"**{name}** added to the story.")
                st.rerun()
            elif submitted:
                st.warning("Please enter a character name.")


# ---------------------------------------------------------------------------
# Random Pitch Generator
# ---------------------------------------------------------------------------

def _render_pitch_generator(genre: str, tone: str):
    """Render the Random Story Pitch section in the sidebar."""
    with st.expander("🎲 Story Pitch Generator", expanded=False):
        if st.button("✨ Generate Random Pitch", use_container_width=True):
            with st.spinner("Conjuring your story premise…"):
                pitch = generate_story_pitch(genre, tone, st.session_state["model"])
            st.session_state["pitch"] = pitch

        pitch = st.session_state.get("pitch")
        if pitch and isinstance(pitch, dict) and pitch.get("title"):
            st.markdown(
                f"""
                <div class="pitch-card">
                    <div class="pitch-title">📖 {pitch.get('title', '')}</div>
                    <div class="pitch-row">🌍 <strong>Setting:</strong> {pitch.get('setting', '')}</div>
                    <div class="pitch-row">👤 <strong>Protagonist:</strong> {pitch.get('protagonist', '')}</div>
                    <div class="pitch-row">⚔️ <strong>Conflict:</strong> {pitch.get('conflict', '')}</div>
                    <div class="pitch-row">🔀 <strong>Twist:</strong> {pitch.get('twist', '')}</div>
                    <div class="pitch-opening">✍️ <em>"{pitch.get('opening_line', '')}"</em></div>
                </div>
                """,
                unsafe_allow_html=True,
            )
            if st.button("🚀 Use This Pitch", use_container_width=True, type="primary"):
                opening = pitch.get("opening_line", "")
                title = pitch.get("title", "New Masterpiece")
                # Set title and inject opening line as first user message
                st.session_state["story_title"] = title
                st.session_state["messages"].append({"role": "user", "content": opening})
                st.session_state["is_generating"] = True
                st.session_state["pitch_autovalidated"] = True   # Skip gatekeeper
                st.session_state["ollama_checked"] = False
                st.session_state["pitch"] = None
                st.rerun()
        elif pitch == {}:
            st.warning("Pitch generation failed. Try again or check Ollama connection.")


# ---------------------------------------------------------------------------
# Internal Helpers
# ---------------------------------------------------------------------------

def _save_current_project():
    """Snapshot the current project state into the projects dict and persist to disk."""
    proj_key = st.session_state.get("current_project")
    if not proj_key:
        return
    proj_data = {
        "history": st.session_state.get("messages", []),
        "characters": st.session_state.get("characters", []),
        "story_summary": st.session_state.get("story_summary", ""),
        "story_title": st.session_state.get("story_title", ""),
        "created_at": st.session_state["projects"].get(proj_key, {}).get("created_at", time.time()),
    }
    st.session_state["projects"][proj_key] = proj_data
    save_project(proj_key, proj_data)
