import streamlit as st
from modules.utils import (
    create_txt_download,
    create_pdf_download,
    render_message,
    render_skeleton,
    save_project,
)
from modules.llm import (
    generate_story,
    check_ollama,
    validate_story_input,
    estimate_tokens,
    summarize_story_so_far,
    TOKEN_THRESHOLD,
)


# ---------------------------------------------------------------------------
# Chat Area — Main Entry Point
# ---------------------------------------------------------------------------

def render_chat_area(settings: dict):
    """Render the centered chat column, handle generation flow, and input controls."""

    # ── Ollama health check (cached per session) ──────────────────────────
    if not st.session_state.get("ollama_checked"):
        ok, err = check_ollama(st.session_state["model"])
        st.session_state["ollama_ok"] = ok
        st.session_state["ollama_err"] = err
        st.session_state["ollama_checked"] = True

    if not st.session_state.get("ollama_ok", False):
        st.error(
            f"🔴 **Ollama Unreachable** — {st.session_state.get('ollama_err', '')}",
            icon="🔴",
        )

    # ── Empty State ───────────────────────────────────────────────────────
    if not st.session_state["messages"]:
        st.markdown(
            """
            <div class="empty-state">
                <div class="empty-icon">✒️</div>
                <h1 class="empty-title">NarrativeFlow</h1>
                <p class="empty-sub">Your story begins with a single line.<br>
                Write a scene, a character beat, or a first sentence.</p>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        # ── Chat History ──────────────────────────────────────────────────
        for msg in st.session_state["messages"]:
            render_message(msg["role"], msg["content"])

    # ── Generation Flow ───────────────────────────────────────────────────
    if st.session_state.get("is_generating"):
        last_msg = st.session_state["messages"][-1] if st.session_state["messages"] else {}
        last_content = last_msg.get("content", "")
        last_role = last_msg.get("role", "")

        # Determine if we should skip scope validation
        auto_valid = (
            st.session_state.get("pitch_autovalidated", False)  # Pitch-seeded message
            or last_content.startswith("Continue this story:")   # Continue button
        )

        if last_role == "user" and not auto_valid:
            with st.spinner("Checking story scope…"):
                is_valid, rejection_msg = validate_story_input(
                    last_content, st.session_state["model"]
                )
            if not is_valid:
                st.session_state["messages"].append({"role": "assistant", "content": rejection_msg})
                st.session_state["is_generating"] = False
                st.session_state["pitch_autovalidated"] = False
                st.rerun()

        # Reset auto-valid flag
        st.session_state["pitch_autovalidated"] = False

        # ── Memory Compression ─────────────────────────────────────────────
        if estimate_tokens(st.session_state["messages"]) > TOKEN_THRESHOLD:
            with st.spinner("Summarizing story memory…"):
                new_summary = summarize_story_so_far(
                    st.session_state["messages"],
                    st.session_state["model"],
                )
            if new_summary:
                st.session_state["story_summary"] = new_summary
                # Keep only the most recent 6 exchanges to stay within context window
                st.session_state["messages"] = st.session_state["messages"][-6:]

        # ── Skeleton Loader ────────────────────────────────────────────────
        render_skeleton()

        if st.session_state.get("ollama_ok", False):
            try:
                response_placeholder = st.empty()
                full_response = ""

                stream = generate_story(
                    messages=st.session_state["messages"],
                    title=settings["title"],
                    genre=settings["genre"],
                    tone=settings["tone"],
                    word_limit=settings["word_limit"],
                    model=st.session_state["model"],
                    system_prompt=st.session_state.get("system_prompt", ""),
                    characters=st.session_state.get("characters", []),
                    story_summary=st.session_state.get("story_summary", ""),
                )

                for chunk in stream:
                    full_response += chunk
                    response_placeholder.markdown(
                        f'<div class="message-row ai-bubble-row">'
                        f'  <div class="avatar ai-avatar">✒️</div>'
                        f'  <div class="ai-story-bubble streaming">{full_response}▌</div>'
                        f'</div>',
                        unsafe_allow_html=True,
                    )

                response_placeholder.empty()
                st.session_state["messages"].append({"role": "assistant", "content": full_response})
                # Auto-save after each generation
                _auto_save()

            except ConnectionError as e:
                st.session_state["ollama_ok"] = False
                st.session_state["ollama_err"] = str(e)
                st.error(f"Generation failed: {e}", icon="🔴")
        else:
            st.warning("Fix the Ollama connection above before generating.", icon="⚠️")

        st.session_state["is_generating"] = False
        st.rerun()

    # ── Input Area ─────────────────────────────────────────────────────────
    st.markdown('<div class="input-spacer"></div>', unsafe_allow_html=True)

    st.text_area(
        "Your narrative input",
        key="screen_input",
        placeholder="Write a scene, a character beat, or a dramatic twist…",
        height=100,
        label_visibility="collapsed",
    )

    c1, c2, c3, c4 = st.columns([2, 1.5, 1.5, 1.5])

    with c1:
        st.button(
            "✨ Generate",
            type="primary",
            use_container_width=True,
            on_click=_handle_generate,
        )
    with c2:
        st.button(
            "▶ Continue",
            use_container_width=True,
            on_click=_handle_continue,
            disabled=not bool(st.session_state.get("messages")),
        )
    with c3:
        st.button(
            "🗑 Clear",
            use_container_width=True,
            on_click=_handle_clear,
        )
    with c4:
        with st.popover("📥 Export"):
            msgs = st.session_state["messages"]
            title = settings["title"]
            st.download_button(
                "📄 TXT — Clean Prose",
                create_txt_download(msgs, title),
                file_name=f"{title}.txt",
                mime="text/plain",
                use_container_width=True,
            )
            st.download_button(
                "📑 PDF — Manuscript",
                create_pdf_download(msgs, title),
                file_name=f"{title}.pdf",
                mime="application/pdf",
                use_container_width=True,
            )


# ---------------------------------------------------------------------------
# Callbacks
# ---------------------------------------------------------------------------

def _handle_generate():
    user_text = st.session_state.get("screen_input", "").strip()
    if user_text:
        st.session_state["messages"].append({"role": "user", "content": user_text})
        st.session_state["screen_input"] = ""
        st.session_state["is_generating"] = True
        st.session_state["ollama_checked"] = False


def _handle_continue():
    if not st.session_state.get("messages"):
        return
    last = st.session_state["messages"][-1]["content"]
    seed = last[:200].strip()
    st.session_state["messages"].append(
        {"role": "user", "content": f"Continue this story: {seed}…"}
    )
    st.session_state["is_generating"] = True
    st.session_state["ollama_checked"] = False


def _handle_clear():
    st.session_state["messages"] = []
    st.session_state["story_summary"] = ""
    st.session_state["ollama_checked"] = False


# ---------------------------------------------------------------------------
# Auto-Save Helper
# ---------------------------------------------------------------------------

def _auto_save():
    """Persist the current project state after each AI response."""
    proj_key = st.session_state.get("current_project")
    if not proj_key:
        return
    import time
    proj_data = {
        "history": st.session_state.get("messages", []),
        "characters": st.session_state.get("characters", []),
        "story_summary": st.session_state.get("story_summary", ""),
        "story_title": st.session_state.get("story_title", ""),
        "created_at": st.session_state["projects"].get(proj_key, {}).get("created_at", time.time()),
    }
    st.session_state["projects"][proj_key] = proj_data
    save_project(proj_key, proj_data)
